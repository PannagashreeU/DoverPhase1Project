﻿
using System;
using System.IO;
namespace readwriteapp
{
    class Class1
    {
        [STAThread]
        static void Main(string[] args)
        {
            int n = 0;
            string x;


            String line;
            try
            {
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr = new StreamReader("teachers_data.txt");
                //Read the first line of text
                line = sr.ReadLine();
                //Continue to read until you reach end of file
                while (line != null)
                {
                    //write the lie to console window
                    Console.WriteLine(line);
                    //Read the next line
                    line = sr.ReadLine();
                }
                //close the file
                sr.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("data store in file.");
            }


         
                using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"teachers_data.txt", true))
                {
                    Console.WriteLine("enter text to add in a file ");
                    string data = Console.ReadLine();
                file.WriteLine();
                    file.WriteLine(data);
                }
            
            

        }
    }
}

